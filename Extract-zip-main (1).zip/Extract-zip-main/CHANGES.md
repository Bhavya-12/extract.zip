# 1.1.1

-   Added ``getMode`` function to be able to
    use fs.chmod on darwin and linux

# 0.0.4

-   Updated dependencies.
-   Reader no longer requires ``new`` keyword
-   ``inflate`` module now at the root

# 0.0.3

-   Fixed for NPM 1.0

# 0.0.2

-   Removed a spurious buffer-io file that was confusing the
    new Node module search algorithm.

# 0.0.1

-   fixed a dependency on q-io

# 0.0.0

-   ported from Tom Robinson's
    <https://github.com/tlrobinson/zipjs> for Narwhal.

